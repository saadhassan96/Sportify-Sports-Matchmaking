/**
 * Sportify
 * Group 5
 * CS360 - Spring 2018
 * Copyright - 19100034@lums.edu.pk
 */

import React, { Component } from 'react';
import {
  Platform,
  Image,
  Text,
  View,
  Button,
  ListView,
  TextInput,
  TouchableOpacity
} from 'react-native';


const styles = require('./styles.js');

class ScreenBG extends Component{
  render() {
    return(
      <View style={styles.screenBG}>
          <Image
            style={styles.imageBG}
            source={require('./assets/images/screensLogoNew.png')}
          />
      </View>
    );
  }
}




class CustomButton extends Component{
  constructor(props) {
    super(props)
    this.state = {text: ''}
  }
  render(){
    return(
      <View style={styles.buttonBG}>
        <TouchableOpacity
          style={styles.buttonStyle}
          onPress={this.props.onPress}
        >
          <Text style={styles.buttonText}>
            {this.props.title}
          </Text>
        </TouchableOpacity>
      </View>
    )
  }
}


class UserInput extends Component{
  constructor(props) {
    super(props);
    this.state = {text: ''};
  }
  render() {
    return (

      <View style={{padding: 10}}>
        <TextInput
          style={{
            height: 40,
            top: 190,
            width:330,

            // borderColor: '#ff6c00', borderWidth: 1.5,
          }}
          underlineColorAndroid='#ff6c00'
          // underlineColorAndroid='transparent'
          autoCorrect={false}
          maxLength = {this.props.maxLength}
          placeholder={this.props.placeholder}
          onChangeText={(text) => this.setState({text})}
          secureTextEntry={this.props.secureTextEntry}
          userInp={this.state.text}
        />

      </View>
    );
  }
}


export default class App extends Component<Props>{
  constructor(props){
    super(props)
    this.state={}
  }
  render() {
    return (
      <View style={styles.mainContainer}>

        <View style={styles.imageContainer}>
          <ScreenBG/>
        </View>
        <Text style={{top: 162,padding: 0,fontSize: 20,textAlign: 'center',alignItems: 'center'}}>
        Please enter the verification code that was send to the email address you entered:
        </Text>


        <View style={styles.contentContainer}>

          <UserInput
            placeholder = "Verification code"
            maxLength = {20}
            secureTextEntry={true}
          />

          <CustomButton
            title = "Verify"
          />

        </View>

      </View>
    );
  }
}
